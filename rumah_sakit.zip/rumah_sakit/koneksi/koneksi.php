<?php
$host   = 'localhost';
$db_name  = 'rumah_sakit';
$db_user  = 'root';
$db_pass  = '';

$conn = mysqli_connect($host, $db_user, $db_pass, $db_name);
if(mysqli_connect_errno($conn)){
 echo 'Koneksi Gagal';
}

// function edit
function edit($id_pasien){
    $data = mysqli_query($this->db_pass, "SELECT *FROM admin where id_pasien='$id_pasien'");
    while($d = mysqli_fetch_array($data)){
        $hasil[] = $d;
    }
    return $hasil;
}

// function update
function update($id_pasien, $nama_pasien, $gender, $umur, $nomer_hp, $alamat, $keluhan, $ruangan, $no_ruangan, $nama_wali){
    mysqli_query($this->koneksi, "UPDATE admin SET nama_pasien='$nama_pasien', gender='$gender', umur='$umur', nomer_hp='$nomor_hp', alamat='$alamat', keluhan='$keluhan', ruangan='$ruangan', no_ruangan='$no_ruangan', nama_wali='$nama_wali'  WHERE id_pasien='$id_pasien'");
}
?>